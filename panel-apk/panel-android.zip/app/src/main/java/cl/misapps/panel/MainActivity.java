package cl.misapps.panel;

import android.app.Activity;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

// Panel de administración de Mimo, Silla y Contador de Bolsillo.
// Se abre con tu huella (o el bloqueo de pantalla) y muestra mimo-cl.github.io/panel/.
public class MainActivity extends Activity {
    private static final String URL = "https://mimo-cl.github.io/panel/";
    private static final int PIN = 7;
    private WebView web;
    private boolean desbloqueado = false, cargado = false, pidiendo = false, porPin = false;
    private long salio = 0;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setBackgroundColor(0xFF111418);
        web.setVisibility(View.INVISIBLE);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setCacheMode(hayInternet() ? WebSettings.LOAD_DEFAULT : WebSettings.LOAD_CACHE_ELSE_NETWORK);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("mimo-cl.github.io".equals(u.getHost()) && u.getPath() != null && u.getPath().startsWith("/panel")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception e) { }
                return true;
            }
        });
        pedirHuella();
    }

    // Pide la huella; si el teléfono no tiene, usa el PIN/patrón del teléfono.
    private void pedirHuella() {
        if (pidiendo) return;
        KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        if (km == null || !km.isDeviceSecure()) { abrir(); return; }
        if (Build.VERSION.SDK_INT >= 28) {
            pidiendo = true;
            BiometricPrompt.Builder bb = new BiometricPrompt.Builder(this)
                    .setTitle("Panel de mis apps")
                    .setSubtitle("Usa tu huella para entrar");
            if (Build.VERSION.SDK_INT >= 30) {
                bb.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK | BiometricManager.Authenticators.DEVICE_CREDENTIAL);
            } else if (Build.VERSION.SDK_INT == 29) {
                bb.setDeviceCredentialAllowed(true);
            } else {
                bb.setNegativeButton("Usar PIN", getMainExecutor(), (d, w) -> { porPin = true; pidiendo = false; pedirPin(km); });
            }
            bb.build().authenticate(new CancellationSignal(), getMainExecutor(), new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r) { pidiendo = false; abrir(); }

                @Override
                public void onAuthenticationError(int code, CharSequence msg) {
                    if (porPin) { porPin = false; return; }
                    pidiendo = false;
                    if (code == BiometricPrompt.BIOMETRIC_ERROR_NO_BIOMETRICS || code == BiometricPrompt.BIOMETRIC_ERROR_HW_NOT_PRESENT
                            || code == BiometricPrompt.BIOMETRIC_ERROR_HW_UNAVAILABLE) pedirPin(km);
                    else finish();
                }
            });
        } else {
            pedirPin(km);
        }
    }

    @SuppressWarnings("deprecation")
    private void pedirPin(KeyguardManager km) {
        Intent i = km.createConfirmDeviceCredentialIntent("Panel de mis apps", "Desbloquea para entrar");
        if (i == null) { abrir(); return; }
        pidiendo = true;
        startActivityForResult(i, PIN);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == PIN) { pidiendo = false; if (res == RESULT_OK) abrir(); else finish(); }
    }

    private void abrir() {
        desbloqueado = true;
        web.setVisibility(View.VISIBLE);
        if (!cargado) { cargado = true; web.loadUrl(URL); }
    }

    @Override
    protected void onPause() { super.onPause(); if (desbloqueado) salio = System.currentTimeMillis(); }

    @Override
    protected void onResume() {
        super.onResume();
        // Si dejaste la app más de 1 minuto, vuelve a pedir la huella.
        if (desbloqueado && salio > 0 && System.currentTimeMillis() - salio > 60000) {
            desbloqueado = false;
            web.setVisibility(View.INVISIBLE);
            pedirHuella();
        }
    }

    private boolean hayInternet() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo n = cm == null ? null : cm.getActiveNetworkInfo();
        return n != null && n.isConnected();
    }

    @Override
    public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
